import { Bot, User, Sparkles } from "lucide-react";

interface Message {
  role: "user" | "assistant";
  content: string;
}

interface ChatResponseProps {
  messages: Message[];
  isLoading: boolean;
}

export function ChatResponse({ messages, isLoading }: ChatResponseProps) {
  if (messages.length === 0 && !isLoading) {
    return (
      <div className="w-full p-8 rounded-xl bg-secondary/30 border-2 border-dashed border-border text-center">
        <div className="w-16 h-16 mx-auto mb-4 rounded-2xl gradient-primary/10 bg-primary/5 flex items-center justify-center">
          <Sparkles className="w-8 h-8 text-primary" />
        </div>
        <h3 className="text-lg font-semibold text-foreground mb-2">
          Ready to Learn!
        </h3>
        <p className="text-sm text-muted-foreground max-w-md mx-auto">
          Extract a YouTube video's content above, then ask any question about it. 
          I'll explain concepts like a personal tutor!
        </p>
      </div>
    );
  }

  return (
    <div className="w-full space-y-4">
      <div className="flex items-center gap-2 mb-2">
        <Bot className="w-5 h-5 text-primary" />
        <label className="text-sm font-medium text-foreground">
          Chatbot Response
        </label>
      </div>
      
      <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2">
        {messages.map((message, index) => (
          <div 
            key={index} 
            className={`flex gap-3 animate-slide-up ${
              message.role === "user" ? "justify-end" : "justify-start"
            }`}
          >
            {message.role === "assistant" && (
              <div className="w-8 h-8 rounded-lg gradient-primary flex items-center justify-center flex-shrink-0">
                <Bot className="w-4 h-4 text-primary-foreground" />
              </div>
            )}
            
            <div 
              className={`max-w-[80%] p-4 rounded-2xl ${
                message.role === "user" 
                  ? "bg-accent text-accent-foreground rounded-br-md" 
                  : "bg-card border-2 border-border text-card-foreground rounded-bl-md shadow-soft"
              }`}
            >
              <p className="text-sm leading-relaxed whitespace-pre-wrap">
                {message.content}
              </p>
            </div>
            
            {message.role === "user" && (
              <div className="w-8 h-8 rounded-lg bg-secondary flex items-center justify-center flex-shrink-0">
                <User className="w-4 h-4 text-secondary-foreground" />
              </div>
            )}
          </div>
        ))}
        
        {isLoading && (
          <div className="flex gap-3 justify-start animate-slide-up">
            <div className="w-8 h-8 rounded-lg gradient-primary flex items-center justify-center flex-shrink-0">
              <Bot className="w-4 h-4 text-primary-foreground" />
            </div>
            <div className="bg-card border-2 border-border rounded-2xl rounded-bl-md p-4 shadow-soft">
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">Processing</span>
                <div className="flex gap-1">
                  <span className="w-2 h-2 rounded-full bg-primary animate-typing-1" />
                  <span className="w-2 h-2 rounded-full bg-primary animate-typing-2" />
                  <span className="w-2 h-2 rounded-full bg-primary animate-typing-3" />
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
