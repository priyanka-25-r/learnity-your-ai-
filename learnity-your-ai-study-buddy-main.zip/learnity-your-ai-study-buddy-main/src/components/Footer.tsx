import { Sparkles, Puzzle, Code2 } from "lucide-react";

export function Footer() {
  return (
    <footer className="w-full border-t border-border/50 bg-card/50 mt-auto">
      <div className="container py-6 px-4 md:px-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-6 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-primary" />
              <span>Powered by Generative AI</span>
            </div>
            <div className="hidden sm:flex items-center gap-2">
              <Puzzle className="w-4 h-4 text-accent" />
              <span>Supports API Integration</span>
            </div>
            <div className="hidden md:flex items-center gap-2">
              <Code2 className="w-4 h-4 text-primary" />
              <span>Gradio-style ML UI</span>
            </div>
          </div>
          
          <p className="text-sm text-muted-foreground">
            © 2024 <span className="font-semibold text-gradient">Learnity</span>. Watch less, understand more.
          </p>
        </div>
      </div>
    </footer>
  );
}
