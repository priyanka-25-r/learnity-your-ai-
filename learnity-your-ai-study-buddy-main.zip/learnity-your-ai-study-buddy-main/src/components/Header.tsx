import { GraduationCap, Sparkles } from "lucide-react";

export function Header() {
  return (
    <header className="w-full border-b border-border/50 bg-card/80 backdrop-blur-sm sticky top-0 z-50">
      <div className="container flex items-center justify-between h-16 px-4 md:px-6">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-10 h-10 rounded-xl gradient-primary flex items-center justify-center shadow-soft">
              <GraduationCap className="w-5 h-5 text-primary-foreground" />
            </div>
            <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full gradient-accent flex items-center justify-center">
              <Sparkles className="w-2.5 h-2.5 text-accent-foreground" />
            </div>
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight">
              <span className="text-gradient">Learnity</span>
            </h1>
            <p className="text-xs text-muted-foreground -mt-0.5">GenAI YouTube Tutor</p>
          </div>
        </div>
        
        <div className="hidden sm:flex items-center gap-2 text-sm text-muted-foreground">
          <span className="px-3 py-1.5 rounded-full bg-secondary text-secondary-foreground font-medium">
            AI-Powered Learning
          </span>
        </div>
      </div>
    </header>
  );
}
