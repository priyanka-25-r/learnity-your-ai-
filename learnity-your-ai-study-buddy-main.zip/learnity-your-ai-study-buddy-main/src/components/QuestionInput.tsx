import { useState } from "react";
import { MessageCircleQuestion, Send, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";

interface QuestionInputProps {
  onAskQuestion: (question: string) => void;
  isLoading: boolean;
  disabled: boolean;
}

export function QuestionInput({ onAskQuestion, isLoading, disabled }: QuestionInputProps) {
  const [question, setQuestion] = useState("");

  const handleSubmit = () => {
    if (!question.trim() || isLoading) return;
    onAskQuestion(question);
    setQuestion("");
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  return (
    <div className="w-full space-y-3">
      <div className="flex items-center gap-2">
        <MessageCircleQuestion className="w-5 h-5 text-accent" />
        <label className="text-sm font-medium text-foreground">
          Ask a Question About the Video
        </label>
      </div>
      
      <div className="relative">
        <Textarea
          placeholder={disabled 
            ? "Extract a video first to start asking questions..." 
            : "What would you like to know about this video? Ask anything!"
          }
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          onKeyDown={handleKeyDown}
          disabled={disabled}
          className="min-h-[100px] pr-24 text-base bg-card border-2 focus:border-accent/50 transition-colors resize-none"
        />
        
        <Button
          onClick={handleSubmit}
          disabled={!question.trim() || isLoading || disabled}
          variant="accent"
          size="default"
          className="absolute bottom-3 right-3"
        >
          {isLoading ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              Thinking...
            </>
          ) : (
            <>
              <Send className="w-4 h-4" />
              Get Response
            </>
          )}
        </Button>
      </div>
      
      {!disabled && (
        <p className="text-xs text-muted-foreground">
          Press Enter to send, Shift+Enter for new line
        </p>
      )}
    </div>
  );
}
