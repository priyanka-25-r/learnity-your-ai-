import { FileText, Copy, CheckCircle2 } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";

interface TranscriptDisplayProps {
  transcript: string;
  videoTitle: string;
}

export function TranscriptDisplay({ transcript, videoTitle }: TranscriptDisplayProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(transcript);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (!transcript) return null;

  return (
    <div className="w-full space-y-3 animate-slide-up">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <FileText className="w-5 h-5 text-primary" />
          <label className="text-sm font-medium text-foreground">
            Video Content
          </label>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={handleCopy}
          className="text-muted-foreground hover:text-foreground"
        >
          {copied ? (
            <>
              <CheckCircle2 className="w-4 h-4 text-primary" />
              Copied!
            </>
          ) : (
            <>
              <Copy className="w-4 h-4" />
              Copy
            </>
          )}
        </Button>
      </div>
      
      {videoTitle && (
        <h3 className="text-lg font-semibold text-foreground">{videoTitle}</h3>
      )}
      
      <div className="relative">
        <div className="w-full min-h-[200px] max-h-[300px] overflow-y-auto p-4 rounded-xl bg-secondary/50 border-2 border-border text-sm leading-relaxed text-secondary-foreground whitespace-pre-wrap">
          {transcript}
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-8 bg-gradient-to-t from-secondary/50 to-transparent rounded-b-xl pointer-events-none" />
      </div>
    </div>
  );
}
