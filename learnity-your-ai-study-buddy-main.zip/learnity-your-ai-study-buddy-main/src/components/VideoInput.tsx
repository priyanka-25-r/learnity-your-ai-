import { useState } from "react";
import { Youtube, Loader2, FileText, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

interface VideoInputProps {
  onTranscriptExtracted: (transcript: string, videoTitle: string) => void;
  isLoading: boolean;
  setIsLoading: (loading: boolean) => void;
}

export function VideoInput({ onTranscriptExtracted, isLoading, setIsLoading }: VideoInputProps) {
  const [url, setUrl] = useState("");
  const [isExtracted, setIsExtracted] = useState(false);

  const handleExtract = async () => {
    if (!url.trim()) return;
    
    setIsLoading(true);
    setIsExtracted(false);
    
    // Simulate extraction for now - will be replaced with actual API call
    setTimeout(() => {
      const mockTranscript = `Welcome to this educational video! Today we'll explore the fascinating world of learning with AI.

The key concepts we'll cover include:

1. **Understanding AI-Powered Learning**
   - How artificial intelligence can personalize education
   - The benefits of interactive learning experiences
   - Real-world applications in classrooms

2. **Effective Study Techniques**
   - Active recall and spaced repetition
   - The Feynman Technique for deep understanding
   - Mind mapping and visual learning

3. **The Future of Education**
   - Adaptive learning systems
   - Virtual tutors and mentors
   - Gamification in education

Remember, the goal isn't just to watch videos, but to truly understand and apply the concepts. Ask questions, take notes, and practice what you learn!

Thank you for watching, and keep learning!`;

      const videoTitle = "AI-Powered Learning: The Future of Education";
      
      onTranscriptExtracted(mockTranscript, videoTitle);
      setIsLoading(false);
      setIsExtracted(true);
    }, 2000);
  };

  const isValidUrl = url.includes("youtube.com") || url.includes("youtu.be");

  return (
    <div className="w-full space-y-4">
      <div className="flex items-center gap-2 mb-2">
        <Youtube className="w-5 h-5 text-destructive" />
        <label className="text-sm font-medium text-foreground">
          Enter YouTube Video URL
        </label>
      </div>
      
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Input
            type="url"
            placeholder="https://www.youtube.com/watch?v=..."
            value={url}
            onChange={(e) => {
              setUrl(e.target.value);
              setIsExtracted(false);
            }}
            className="h-12 pl-4 pr-10 text-base bg-card border-2 focus:border-primary/50 transition-colors"
          />
          {isExtracted && (
            <CheckCircle2 className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-primary" />
          )}
        </div>
        
        <Button 
          onClick={handleExtract}
          disabled={!url.trim() || isLoading}
          variant="hero"
          size="lg"
          className="min-w-[160px]"
        >
          {isLoading ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              Extracting...
            </>
          ) : (
            <>
              <FileText className="w-4 h-4" />
              Extract Content
            </>
          )}
        </Button>
      </div>
      
      {url && !isValidUrl && (
        <p className="text-sm text-muted-foreground">
          Please enter a valid YouTube URL
        </p>
      )}
    </div>
  );
}
