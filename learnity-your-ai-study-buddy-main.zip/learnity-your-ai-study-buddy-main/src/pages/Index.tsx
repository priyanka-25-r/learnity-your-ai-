import { useState } from "react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { VideoInput } from "@/components/VideoInput";
import { TranscriptDisplay } from "@/components/TranscriptDisplay";
import { QuestionInput } from "@/components/QuestionInput";
import { ChatResponse } from "@/components/ChatResponse";

interface Message {
  role: "user" | "assistant";
  content: string;
}

const Index = () => {
  const [transcript, setTranscript] = useState("");
  const [videoTitle, setVideoTitle] = useState("");
  const [messages, setMessages] = useState<Message[]>([]);
  const [isExtracting, setIsExtracting] = useState(false);
  const [isResponding, setIsResponding] = useState(false);

  const handleTranscriptExtracted = (content: string, title: string) => {
    setTranscript(content);
    setVideoTitle(title);
    setMessages([]);
  };

  const handleAskQuestion = (question: string) => {
    setMessages((prev) => [...prev, { role: "user", content: question }]);
    setIsResponding(true);

    // Simulate AI response - will be replaced with actual API call
    setTimeout(() => {
      const response = generateMockResponse(question, transcript);
      setMessages((prev) => [...prev, { role: "assistant", content: response }]);
      setIsResponding(false);
    }, 1500);
  };

  return (
    <div className="min-h-screen flex flex-col gradient-hero">
      <Header />
      
      <main className="flex-1 container py-8 px-4 md:px-6">
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Hero Section */}
          <div className="text-center space-y-4 mb-10">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground">
              Transform Videos into
              <span className="text-gradient"> Interactive Learning</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Paste any YouTube video URL and let AI help you understand the content. 
              Ask questions, get explanations, and learn at your own pace.
            </p>
          </div>

          {/* Main Content Card */}
          <div className="bg-card rounded-2xl shadow-card border border-border/50 p-6 md:p-8 space-y-8">
            {/* Step 1: Video Input */}
            <section>
              <div className="flex items-center gap-2 mb-4">
                <span className="w-7 h-7 rounded-full gradient-primary text-primary-foreground text-sm font-bold flex items-center justify-center">
                  1
                </span>
                <h3 className="text-lg font-semibold text-foreground">Add Your Video</h3>
              </div>
              <VideoInput 
                onTranscriptExtracted={handleTranscriptExtracted}
                isLoading={isExtracting}
                setIsLoading={setIsExtracting}
              />
            </section>

            {/* Step 2: Transcript Display */}
            {transcript && (
              <section>
                <div className="flex items-center gap-2 mb-4">
                  <span className="w-7 h-7 rounded-full gradient-primary text-primary-foreground text-sm font-bold flex items-center justify-center">
                    2
                  </span>
                  <h3 className="text-lg font-semibold text-foreground">Review Content</h3>
                </div>
                <TranscriptDisplay transcript={transcript} videoTitle={videoTitle} />
              </section>
            )}

            {/* Step 3: Question Input */}
            <section>
              <div className="flex items-center gap-2 mb-4">
                <span className={`w-7 h-7 rounded-full text-sm font-bold flex items-center justify-center ${
                  transcript 
                    ? "gradient-accent text-accent-foreground" 
                    : "bg-secondary text-secondary-foreground"
                }`}>
                  3
                </span>
                <h3 className={`text-lg font-semibold ${transcript ? "text-foreground" : "text-muted-foreground"}`}>
                  Ask Questions
                </h3>
              </div>
              <QuestionInput 
                onAskQuestion={handleAskQuestion}
                isLoading={isResponding}
                disabled={!transcript}
              />
            </section>

            {/* Chat Response */}
            <section>
              <ChatResponse messages={messages} isLoading={isResponding} />
            </section>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

// Mock response generator - will be replaced with actual AI
function generateMockResponse(question: string, transcript: string): string {
  const lowerQuestion = question.toLowerCase();
  
  if (lowerQuestion.includes("summary") || lowerQuestion.includes("summarize")) {
    return `Based on the video content, here's a comprehensive summary:

The video discusses AI-powered learning and its transformative potential in education. The main points covered are:

1. **AI Personalization**: How artificial intelligence can adapt to individual learning styles and paces
2. **Effective Techniques**: Including active recall, spaced repetition, and the Feynman Technique
3. **Future Outlook**: Adaptive systems, virtual tutors, and gamification

The key takeaway is that technology should enhance understanding, not just information consumption. The goal is to "watch less and understand more."`;
  }
  
  if (lowerQuestion.includes("feynman") || lowerQuestion.includes("technique")) {
    return `Great question! The Feynman Technique mentioned in the video is a powerful learning method named after physicist Richard Feynman.

**How it works:**
1. **Choose a concept** you want to learn
2. **Explain it simply** as if teaching a child
3. **Identify gaps** in your understanding
4. **Review and simplify** your explanation

The beauty of this technique is that it forces you to truly understand something, not just memorize it. If you can't explain it simply, you don't understand it well enough!

Would you like me to explain any other concept from the video?`;
  }
  
  return `That's an excellent question about the video content!

Based on what was covered, here's what I can share:

The video emphasizes that effective learning isn't about passive consumption—it's about active engagement with the material. The key strategies mentioned include:

• **Active recall**: Testing yourself rather than just re-reading
• **Spaced repetition**: Reviewing material at increasing intervals
• **Visual learning**: Using mind maps and diagrams

These techniques, combined with AI-powered tools like this one, can significantly enhance your learning experience.

Is there a specific part of the video you'd like me to elaborate on?`;
}

export default Index;
